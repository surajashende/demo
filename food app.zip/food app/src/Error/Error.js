import React from 'react'
import './Error.css'
function Error() {
    return (
        <div className="Error">
           <h1> !!!Error....... Page Not Found</h1>

        </div>
    )
}

export default Error
