export const increment = (product) => {
  return {
    
    type: 'increment',
    
  }
}

export const decrement = (product) => {
  return {
    type: 'decrement',
    
    
  }
}
