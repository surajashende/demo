import { createContext } from 'react'

const ProductContext = createContext(null)

export default ProductContext

