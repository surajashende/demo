import React from 'react'

const Order = () => {

    
    return (
        <div>
            <center><h3>Your Order has been Placed</h3>
            </center>
        </div>
    )
}

export default Order
