import React from 'react'

const CartDetails = () => {
    return (
        <div>
            
        </div>
    )
}

export default CartDetails
